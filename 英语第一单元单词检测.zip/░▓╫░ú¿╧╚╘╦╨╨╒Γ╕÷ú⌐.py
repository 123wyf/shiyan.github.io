from itertools import islice
st = open ("存储文件，不要删除！.reiiio","w+")
with open("存储文件，不要删除！.reiiio") as f:
    st.write("！！！"+"\n")
    st.write("0")
    pass
st = open ("存储文件，不要删除！.reiiio","r")
with open("存储文件，不要删除！.reiiio") as f:
    金币=(f.read())
    pass
if 金币 =="！！！"+"\n"+"0":
    print("安装成功")
else:
    print("安装失败")
input()
